package com.example.work4.javascriptcallfunc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyBroadcaseReceiver2 extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		//String sender = intent.getStringExtra("sender_name");
		Toast.makeText(context, "Thank you for playing. Have a nice day. Bye bye.",
				Toast.LENGTH_LONG).show();

	}

}
