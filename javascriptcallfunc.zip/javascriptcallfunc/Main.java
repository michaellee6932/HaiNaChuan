package com.example.work4.javascriptcallfunc;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import java.net.URLDecoder;
import java.util.Calendar;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.Dialog;
import android.content.*;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

public class Main extends Activity implements OnClickListener {

    //Web
    private Button mBtnLoadHtml,mBtnShowImage,mBtnBuildHtml;
    private WebView mWebView;

    //Game
    private final String LOG_TAG = "activity lifecycle";
    private Button mBtnExecGame;
    private TextView mTxtResult;
    final private int LAUNCH_GAME = 0;

    //Gallery
    private Button mBtnShowGallery;

    //Event Handler
    private Handler mHandler = new Handler();

    class MyThread2 extends Thread {

        MyThread2(String s) {
            super(s);
        }

        public void run() {

            new MyThread3().run();
        }
    }

    class MyThread3 implements Runnable {

        public void run() {
            mWebView.loadUrl("https://www.google.com");
        }
    }

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        Log.d(LOG_TAG, "Main.onCreate()");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        setupViewComponent();
    }

    @SuppressLint("JavascriptInterface")
    private void setupViewComponent() {
        //Web
        mBtnLoadHtml = (Button)findViewById(R.id.btnLoadHtml);
        mBtnShowImage = (Button)findViewById(R.id.btnShowImage);
        mBtnBuildHtml = (Button)findViewById(R.id.btnBuildHtml);
        mWebView = (WebView)findViewById(R.id.webView);

        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mWebView.addJavascriptInterface(new JavaScriptCallFunc(this), "Android");

        //Web
        mBtnLoadHtml.setOnClickListener(this);
        mBtnShowImage.setOnClickListener(this);
        mBtnBuildHtml.setOnClickListener(this);

        //Game
        mTxtResult = (TextView)findViewById(R.id.txtResult);
        mBtnExecGame = (Button)findViewById(R.id.btnExecGame);
        mBtnExecGame.setOnClickListener(btnExecGameOnClkLis);

        //Gallery
        mBtnShowGallery = (Button)findViewById(R.id.btnShowGallery);
        mBtnShowGallery.setOnClickListener(btnShowGalleryOnClkLis);
    }

    //Main activity
    @Override
    protected void onDestroy() {
        Log.d(LOG_TAG, "Main.onDestroy()");

        // TODO Auto-generated method stub
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        Log.d(LOG_TAG, "Main.onPause()");

        // TODO Auto-generated method stub
        super.onPause();
    }

    @Override
    protected void onRestart() {
        Log.d(LOG_TAG, "Main.onRestart()");

        // TODO Auto-generated method stub
        super.onRestart();
    }

    protected void onResume() {
        Log.d(LOG_TAG, "Main.onResume()");
    @Override

        // TODO Auto-generated method stub
        super.onResume();
    }

    @Override
    protected void onStart() {
        Log.d(LOG_TAG, "Main.onStart()");

        // TODO Auto-generated method stub
        super.onStart();
    }

    @Override
    protected void onStop() {
        Log.d(LOG_TAG, "Main.onStop()");

        // TODO Auto-generated method stub
        super.onStop();
    }//Main activity

    //Invoke Game Activity
    private Button.OnClickListener btnExecGameOnClkLis = new Button.OnClickListener() {
        public void onClick(View v) {
            //Broadcasting
            Intent it1 = new Intent("tw.android.MY_BROADCAST1");
            //it1.putExtra("sender_name", "aaa");
            sendBroadcast(it1);//

            Intent it = new Intent();
            it.setClass(Main.this, Game.class);
            startActivityForResult(it, LAUNCH_GAME);
        }
    };

    //Get game result
    protected void onActivityResult(int requestCode, int resultCode, Intent  data) {
        if (requestCode != LAUNCH_GAME)
            return;

        switch (resultCode) {
            case RESULT_OK:
                Bundle bundle = data.getExtras();
                String roundNumber = "";

                int iCountSet = bundle.getInt("KEY_COUNT_SET");
                int iCountPlayerWin = bundle.getInt("KEY_COUNT_PLAYER_WIN");
                int iCountComWin = bundle.getInt("KEY_COUNT_COM_WIN");
                int iCountDraw = bundle.getInt("KEY_COUNT_DRAW");

                if(iCountSet >1) roundNumber = "Rounds";
                else roundNumber = "Round";

                String s = "Game Result：Total Play -> " + iCountSet +
                        " " + roundNumber + ", Win -> " + iCountPlayerWin +
                        ", Lose -> " + iCountComWin +
                        ", Draw -> " + iCountDraw;
                mTxtResult.setText(s);

                break;
            case RESULT_CANCELED: mTxtResult.setText("");;
                //mTxtResult.setText("Thank you for playing. Have a nice day. Bye bye.");
        }

    }

    //Invoke Gallery Activity
    private Button.OnClickListener btnShowGalleryOnClkLis = new Button.OnClickListener() {
        public void onClick(View v) {
            Intent it = new Intent();
            it.setClass(Main.this, ImageGallery.class);
            startActivityForResult(it, 0);
        }
    };

    //Invoke Web Activity
    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub

        switch (v.getId()) {
            case R.id.btnLoadHtml:
                mWebView.loadUrl("file:///android_asset/my_web_page.html");
                //mWebView.loadUrl("https://www.google.com");
                break;
            case R.id.btnShowImage:
                mWebView.loadUrl("javascript:showImage()");
                break;
            case R.id.btnBuildHtml:
                final ProgressDialog progDlg = new ProgressDialog(Main.this);
                progDlg.setTitle("Please hold on.");
                progDlg.setMessage("In progress....");
                progDlg.setIcon(android.R.drawable.ic_dialog_info);
                progDlg.setCancelable(false);
                progDlg.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                progDlg.setMax(100);
                progDlg.show();

                new Thread(new Runnable() {
                    public void run() {
                        Calendar begin = Calendar.getInstance();
                        do {
                            Calendar now = Calendar.getInstance();
                            final int iDiffSec = 60 * (now.get(Calendar.MINUTE) - begin.get(Calendar.MINUTE)) +
                                    now.get(Calendar.SECOND) - begin.get(Calendar.SECOND);
                            int progDlgProgress;
                            progDlgProgress = progDlg.getProgress();
                            if (progDlgProgress >= 100) {
                                mHandler.post(new Runnable() {
                                    public void run() {
                                        progDlg.setProgress(100);
                                    }
                                });
                                MyThread2 t1 = new MyThread2("WebShow");
                                t1.start();
                                break;
                            }
                            mHandler.post(new Runnable() {
                                public void run() {
                                    progDlg.setProgress(iDiffSec * 20);
                                }
                            });
                            /*if (iDiffSec * 4 < 100)
                                mHandler.post(new Runnable() {
                                    public void run() {
                                        progDlg.setSecondaryProgress(iDiffSec * 4);
                                    }
                                });
                            else
                                mHandler.post(new Runnable() {
                                    public void run() {
                                        progDlg.setSecondaryProgress(100);
                                    }
                                });*/
                        } while (true);
                        progDlg.cancel();
                    }
                }).start();

                break;
        }
    }
}
