package com.example.work4.javascriptcallfunc;

/**
 * Created by work4 on 2016/5/6 0006.
 */
import android.content.Context;
import android.widget.Toast;

public class JavaScriptCallFunc {
    Context mContext;

    JavaScriptCallFunc(Context c) {
        mContext = c;
    }

    public void showToastMsg(String s) {
        Toast.makeText(mContext, s, Toast.LENGTH_LONG)
                .show();
    }
}
